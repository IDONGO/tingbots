# REY SEBASTIAN
# GHOST HUNTER DEATH
# BOT PROTECT ANTI JS
# 1 ADMIN + 4 ASIST
# jangan gunakan untuk merugikan orang lain
# jika ada yang ingin ditanyakan bisa add saya
# id line saya: rey_tlangu
# saling berbagi ilmu
# YOUTUBE: https://www.youtube.com/channel/UCiaIqkq-haV6TTDbATDRIOQ
#
# GHDPROTECTION
# CARA INSTALL BOTNYA ADA DI BAWAH
# HARAP TELITI DALAM MENGINSTALL DAN MENULIS TEXTNYA
# SALAH SATU HURUFPUN DAPAT MENYEBABKAN ERROR BOTNYA

# GET TOKEN :

# Gunakan bot dengan bijak ya
# Bot ini menggunakan header IOSPAD
-
# Cara Install Bot :

# HEADER IOSPAD

# C9 SERVER/ VPS :
# sudo apt-get update -y
# sudo apt-get install git -
# sudo apt-get install python3-pip -y
# sudo pip3 install rsa
# sudo pip3 install thrift==0.11.0
# sudo pip3 install requests
# sudo pip3 install pytz
# sudo pip3 install bs4
# sudo pip3 install gtts
# sudo pip3 install googletrans
# sudo pip3 install humanfriendly
# sudo pip3 install goslate
# sudo pip3 install pafy
# sudo pip3 install wikipedia
# sudo pip3 install tweepy
# sudo pip3 install youtube_dl
# git clone https://github.com/reysebastian/reymia
# cd reymia
# python rey.py

# INSTALL Di TERMUX :
# pkg update
# pkg install git
# pkg install python3-pip
# pip3 install rsa
# pip3 install thrift==0.11.0
# pip3 install requests
# pip3 install bs4
# pip3 install gtts
# pip3 install beautifulsoup
# pip3 install googletrans
# pip3 install pafy
# pip3 install humanfriendly
# pip3 install goslate
# pip3 install wikipedia
# pip3 install youtube_dl
# pip3 install tweepy
# git clone https://github.com/reysebastian/reymia
# cd reymia
# python3 rey.py

# Cara Menjalankan Bot Kembali :

# Di C9 :
# cd reymia
# python3 rey.py

# Di Termux :
# cd reymia
# python3 rey.py


# EDITOR BY REY SEBASTIAN

# Add My ID LINE : rey_tlangu
# GHOST HUNTER DEATH TEAM BOT


 







